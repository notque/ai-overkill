# Frozen philosophy interpretation corpus

30 cases: 20 development, 10 holdout. Designed from the original docs/PHILOSOPHY.md and the user scope; no candidate documents read. Prompts test applied decisions and evidence boundaries, not prose preferences, exact wording, historical-number recall, or terminal execution.

Present one philosophy variant and one prompt per isolated response. Blind labels, fixed model/configuration and balanced ordering belong to the runner. Grade each criterion independently as satisfied or not satisfied using semantic equivalence; do not require particular phrases. Score one point per check (90 total, 60 dev/30 holdout). Critical-failure lists are intentionally empty: checks already cover unsafe or unsupported conclusions without an extra penalty scheme. Report cases and checks separately, including each boundary miss.

Holdout files must remain excluded from revision feedback until candidate selection is frozen. Calibration outputs are separately labeled only in expected judgments; their output_id suffixes are calibration fixtures, never experiment arms. Use calibration to verify obvious good/bad separation before blind grading.

These cases assess preserved operational interpretation, not live tool compliance or end-to-end task success. A ceiling-bound baseline means this corpus cannot discriminate; do not infer equivalence. Some scenarios distinguish user-authorized autonomy from optional workflow ceremony because the user explicitly requires that boundary; historical fixed model tables are not mandatory current-model behavior.
