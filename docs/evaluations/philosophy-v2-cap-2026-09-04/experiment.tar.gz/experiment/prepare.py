import hashlib,json,pathlib
R=pathlib.Path('/tmp/vexjoy-philosophy-v2-trial');OLD=pathlib.Path('/tmp/vexjoy-philosophy-corpus');NEW=pathlib.Path('/tmp/vexjoy-philosophy-fresh-holdout')
def rows(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
for source in (OLD,NEW):
 for line in (source/'SHA256SUMS').read_text().splitlines():
  digest,name=line.split(maxsplit=1);p=pathlib.Path(name.lstrip('*'));p=p if p.is_absolute() else source/p
  assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,str(p)
assert hashlib.sha256((R/'inputs/challenger.md').read_bytes()).hexdigest()=='e8c33c22987ba0a3cbaa8cbe24314d3b5162a07c0bb2c7b8263b131868f671e3'
expected_harness={'runner.py':'f2fa499b11d4f641c6603762c8870520b48f2abc0c09f1d97f9ba39d6a5dedbc','judge.py':'01da7fd984a84e71c08f4b3a5c173d666b73fe6cc67b2b78c2f9fef964fc6666','assess.py':'d35ad8fbf45d1a7e4ac087f3f5cbb117491f26bf2270d2312324cf8c768d829f'}
for name,h in expected_harness.items():assert hashlib.sha256((R/'harness'/name).read_bytes()).hexdigest()==h
cases=[];rubrics=[];mapping={};by_origin={}
for source,stems,suite in [(OLD,['dev','holdout'],'dev'),(NEW,['holdout'],'holdout')]:
 n=0
 for stem in stems:
  rs={r['id']:r for r in rows(source/(stem+'.rubrics.jsonl'))}
  for p in rows(source/(stem+'.prompts.jsonl')):
   n+=1;uid=('v2dev' if suite=='dev' else 'v2hold')+f'{n:03d}';r=rs[p['id']]
   filename='inputs/'+uid+'.txt';(R/filename).write_text(p['prompt']+'\n');cases.append({'id':uid,'suite':suite,'prompt_file':filename})
   rubric={'id':uid,'checks':[{'id':uid+f'.c{i+1}','criterion':c['criterion']} for i,c in enumerate(r['checks'])],'critical_failures':r.get('critical_failures',[])};rubrics.append(rubric)
   mapping[uid]={'source_directory':str(source),'source_prompt_file':stem+'.prompts.jsonl','source_id':p['id'],'original_suite':stem,'trial_suite':suite,'exposure':'previous outcomes exposed; development only' if suite=='dev' else 'fresh independently authored holdout; unseen by candidate author'}
   by_origin[(str(source),p['id'])]=(p,r,rubric)
assert len(cases)==40 and sum(c['suite']=='dev' for c in cases)==30
write(R/'cases.json',cases);write(R/'private/case-id-map.json',mapping);(R/'rubrics/all.rubrics.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rubrics))
expect={x['output_id']:x for x in rows(NEW/'calibration.expected.jsonl')};packets=[];calmap={}
for c in rows(NEW/'calibration.outputs.jsonl'):
 pid=hashlib.sha256(('v2calibration:49072026:'+c['output_id']).encode()).hexdigest()[:24];p,oldr,r=by_origin[(str(NEW),c['id'])]
 rubric={'checks':r['checks'],'critical_failures':r['critical_failures']};packets.append({'id':pid,'request':p['prompt'],'context':'','response':c['output'],'rubric':rubric})
 scores={r['checks'][i]['id']:int(expect[c['output_id']]['expected_checks'][x['id']]) for i,x in enumerate(oldr['checks'])}
 calmap[pid]={'source_output_id':c['output_id'],'expected_checks':scores,'critical_failures':[]}
assert len(packets)==6
serialized=''.join(json.dumps(p)+'\n' for p in packets)
assert '.good' not in serialized and '.bad' not in serialized
(R/'calibration-packets.jsonl').write_text(serialized);write(R/'private/calibration-map.json',calmap)
protocol={'version':2,'model':'gpt-6-astra','effort':'low','seed':49072026,'repeats':5,'timeout_seconds':180,'cases_file':'cases.json','arms':{'baseline':{'instruction_file':'inputs/baseline.md'},'challenger':{'instruction_file':'inputs/challenger.md'}},'common_context_files':['inputs/contract.txt'],'case_count':40,'worker_count':400,'development_count':30,'fresh_holdout_count':10,'metric':'For each repeat, corpus median of input_tokens+output_tokens across40cases; primary arm metric median of its five corpusmedians. Cached input is included, not counted twice.','target_reduction':0.20,'variance_tolerance':'saving must strictly exceed2times range(max-min) of five baseline corpusmedians','floor':'All400workers valid under raw verifier and response contract; calibration6controls exact in2passes; no per-case mean utility regression across5repeats; no new critical loss; unresolved judge disagreement=>inconclusive.40cases explicit denominator.','adjudication':'Copied V1 rule: independent blind corpus author resolves only disputed checks, using full frozen rubric and both votes/evidence; lock before revealing arms; preserve both original votes; unresolved=>inconclusive.','scope':'Operational interpretation of supplied philosophy; no live autonomous behavior or production equivalence claim. Old30cases are development after V1 outcome exposure.','failures':'Retain invalid attempts and all known/unknown spend. No silent retries or replacement; invalid worker blocks acceptance.','harness_source_commit':'e72bc9907eda7384153795df6349cc31b52fe2f5','source_policy_git':'78d1ccf3:docs/PHILOSOPHY.md','candidate_sha256':'e8c33c22987ba0a3cbaa8cbe24314d3b5162a07c0bb2c7b8263b131868f671e3'}
write(R/'protocol.json',protocol)
tracked=[p for p in R.rglob('*') if p.is_file()];write(R/'preregistration.json',{'input_hashes':{str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in tracked},'source_corpus_manifests':{str(p/'SHA256SUMS'):hashlib.sha256((p/'SHA256SUMS').read_bytes()).hexdigest() for p in (OLD,NEW)},'candidate_frozen_before_fresh_calibration':True})
print(json.dumps({'cases':len(cases),'calibration_packets':len(packets),'candidate_sha256':protocol['candidate_sha256'],'preregistration_sha256':hashlib.sha256((R/'preregistration.json').read_bytes()).hexdigest()}))
