import collections,hashlib,json,pathlib,statistics,sys
R=pathlib.Path(__file__).parent;sys.path.insert(0,str(R/'harness'))
import runner,judge,assess

def read(p):return json.loads(p.read_text())
def lines(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def calibration():
 root=R/'calibration-judges';summary=read(root/'summary.json');expected=read(R/'private/calibration-map.json');packets=lines(R/'calibration-packets.jsonl');lookup={p['id']:p for p in packets};errors=[];scores=[];usage=collections.Counter()
 for batch in root.glob('pass-*/result.json'):
  result=read(batch);folder=batch.parent
  if not result['valid']:errors.append({'batch':folder.name,'error':result.get('error')});continue
  raw=(folder/'events.jsonl').read_text();assert judge.parse_events(raw)==result['usage'];usage.update(result['usage'])
  final=read(folder/'final.json');events=lines(folder/'events.jsonl');messages=[e['item']['text'] for e in events if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='agent_message'];assert json.loads(messages[-1])==final
  ps=[lookup[x] for x in result['packet_ids']];judgments=judge.validate(final,ps);assert judgments==result['judgments']
  assert (folder/'prompt.txt').read_text()==judge.INSTRUCTION+'\nPACKETS:\n'+json.dumps(ps,ensure_ascii=False)
  for j in judgments:
   actual={c['id']:c['score'] for c in j['checks']}
   if actual!=expected[j['id']]['expected_checks'] or any(c['violated'] for c in j['critical_violations']):errors.append({'id':j['id'],'pass':result['pass'],'actual':actual,'expected':expected[j['id']]['expected_checks']})
   scores.append((j['id'],result['pass']))
 assert len(scores)==len(set(scores))
 complete=set(scores)=={(p['id'],i) for p in packets for i in (1,2)}
 verdict={'valid':summary['valid'] and complete and not errors,'controls':6,'passes':2,'judgments':len(scores),'exact':not errors,'errors':errors,'usage':dict(usage),'total_tokens':usage['input_tokens']+usage['output_tokens']}
 write(R/'calibration-verdict.json',verdict);print(json.dumps(verdict));return verdict['valid']
def workers():
 manifest,protocol,cases,records=assess.records(R/'results','all');assert len(records)==400 and len(cases)==40
 samples=collections.defaultdict(list);usage=collections.Counter();failures=[]
 for a,r,_ in records:
  contract=isinstance(r['answer'],dict) and set(r['answer'])=={'answer'} and isinstance(r['answer']['answer'],str) and len(r['answer']['answer'].split())<=180
  if not r['success'] or not contract:failures.append({'uid':a['uid'],'case_id':a['case_id'],'arm':a['arm'],'raw_success':r['success'],'contract_valid':contract})
  if r['usage_known']:
   u=r['usage'];usage.update(u);samples[(a['arm'],a['repeat'])].append(u['input_tokens']+u['output_tokens'])
 medians={arm:[statistics.median(samples[(arm,i)]) for i in range(5)] for arm in ('baseline','challenger')}
 complete=all(len(samples[(arm,i)])==40 for arm in ('baseline','challenger') for i in range(5))
 b,c=(statistics.median(medians[arm]) for arm in ('baseline','challenger'));spread=max(medians['baseline'])-min(medians['baseline']);saving=b-c
 report={'workers':400,'cases':40,'raw_and_contract_valid':not failures,'failures':failures,'token_denominator_complete':complete,'corpus_medians':medians,'baseline_median':b,'challenger_median':c,'saving':saving,'reduction':saving/b,'baseline_spread':spread,'variance_threshold':2*spread,'token_target_passes':saving/b>=.2 and saving>2*spread,'usage':dict(usage),'total_tokens':usage['input_tokens']+usage['output_tokens']}
 write(R/'worker-report.json',report);print(json.dumps(report));return not failures and complete
def disputes():
 private=read(R/'private/judge-map.json');packets=[private['packets'][p]['packet'] for p in private['packet_order']];rows=assess.verified_judgments(R/'judges',packets,private['judge_config']);by=collections.defaultdict(list)
 for row in rows:by[row['id']].append(row)
 disputed=[]
 for p in packets:
  votes=by[p['id']];assert len(votes)==2
  a,b=[{c['id']:c['score'] for c in v['checks']} for v in votes];ids=[cid for cid in a if a[cid]!=b[cid]]
  if ids:disputed.append({**p,'disputed_checks':ids,'votes':votes})
 write(R/'disputed-blind.json',disputed);write(R/'private/verified-judge-rows.json',rows);print(json.dumps({'packets':len(packets),'judgments':len(rows),'disputed_packets':len(disputed),'disputed_checks':sum(len(p['disputed_checks']) for p in disputed),'sha256':hashlib.sha256((R/'disputed-blind.json').read_bytes()).hexdigest()}));return True
if __name__=='__main__':raise SystemExit(0 if {'calibration':calibration,'workers':workers,'disputes':disputes}[sys.argv[1]]() else 1)
