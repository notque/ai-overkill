import collections,hashlib,json,pathlib,statistics,sys
R=pathlib.Path(__file__).parent;sys.path.insert(0,str(R/'harness'))
import assess,runner
from fractions import Fraction

def read(p):return json.loads(p.read_text())
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
private=read(R/'private/judge-map.json');packets=[private['packets'][x]['packet'] for x in private['packet_order']];rows=assess.verified_judgments(R/'judges',packets,private['judge_config']);by=collections.defaultdict(list)
for row in rows:by[row['id']].append(row)
disputes=read(R/'disputed-blind.json');need={(p['id'],c) for p in disputes for c in p['disputed_checks']};adjudication_path=R/'adjudications.json';resolved={};adjudication_status='not_needed'
if need and adjudication_path.exists():
 a=read(adjudication_path);lock=read(R/'adjudication-lock.json');assert hashlib.sha256(adjudication_path.read_bytes()).hexdigest()==lock['sha256'];assert lock['locked_before_arm_reveal'] is True
 for row in a['adjudications']:
  key=(row['id'],row['check_id']);assert key in need and key not in resolved;assert type(row['score']) is int and row['score'] in (0,1);assert row['evidence'].strip() and row['rationale'].strip();resolved[key]=row['score']
 adjudication_status='resolved' if set(resolved)==need else 'incomplete'
unresolved=need-set(resolved);utility=collections.defaultdict(list);critical=collections.defaultdict(int)
for p in packets:
 votes=by[p['id']];assert len(votes)==2;mapping=private['packets'][p['id']]['assignment'];v1,v2=[{c['id']:c['score'] for c in v['checks']} for v in votes];checks={}
 for cid in v1:
  if v1[cid]==v2[cid]:checks[cid]=v1[cid]
  elif (p['id'],cid) in resolved:checks[cid]=resolved[(p['id'],cid)]
 if len(checks)==len(v1):utility[(mapping['case_id'],mapping['arm'])].append(Fraction(sum(checks.values()),len(checks)))
 for left,right in zip(votes[0]['critical_violations'],votes[1]['critical_violations']):
  assert left['criterion']==right['criterion'];assert left['violated']==right['violated'],'Unresolved critical judgment';critical[(mapping['case_id'],mapping['arm'])]+=int(left['violated'])
caseids=sorted({a['assignment']['case_id'] for a in private['packets'].values()});assert len(caseids)==40 and len(packets)==400
report=[];regressions=[]
for cid in caseids:
 vals={arm:sum(utility[(cid,arm)],Fraction(0))/len(utility[(cid,arm)]) if len(utility[(cid,arm)])==5 else None for arm in ('baseline','challenger')}
 reg=all(v is not None for v in vals.values()) and (vals['challenger']<vals['baseline'] or critical[(cid,'challenger')]>critical[(cid,'baseline')])
 if reg:regressions.append(cid)
 report.append({'id':cid,'means':{arm:float(v) if v is not None else None for arm,v in vals.items()},'exact_means':{arm:str(v) if v is not None else None for arm,v in vals.items()},'critical':{arm:critical[(cid,arm)] for arm in ('baseline','challenger')},'regression':reg})
w=read(R/'worker-report.json');cal=read(R/'calibration-verdict.json');status='INCONCLUSIVE' if unresolved else 'REJECT' if regressions or not w['raw_and_contract_valid'] or not w['token_target_passes'] or not cal['valid'] else 'REVIEW_READY'
usage={};unknown=[]
for category,directory in [('workers',R/'results/raw'),('calibration',R/'calibration-judges'),('judges',R/'judges')]:
 total=collections.Counter();attempts=0
 for p in directory.rglob('result.json'):
  row=read(p);attempts+=1
  if isinstance(row.get('usage'),dict):total.update(row['usage'])
  else:unknown.append(str(p.relative_to(R)))
 usage[category]={'attempts':attempts,**dict(total),'total_tokens':total['input_tokens']+total['output_tokens']}
adj_usage_path=R/'adjudication-usage.json'
if adj_usage_path.exists():usage['adjudication']=read(adj_usage_path)
else:usage['adjudication']={'total_tokens':None,'status':'No separately metered usage available' if need else 'not needed'}
known_total=sum(v.get('total_tokens') or 0 for v in usage.values())
verdict={'status':status,'scope':'40case written philosophy interpretation, not live agent or production equivalence','workers':400,'development_cases':30,'fresh_holdout_cases':10,'case_utility':report,'regressions':regressions,'unresolved_disputed_checks':sorted(unresolved),'adjudication_status':adjudication_status,'original_judge_votes_preserved':True,'token_metric':w,'calibration':cal,'measurement_usage':usage,'known_measurement_tokens':known_total,'unknown_usage_records':unknown,'adjudication_tokens_in_total':adj_usage_path.exists() or not need,'production_authorized':False}
write(R/'VERDICT.json',verdict);print(json.dumps({'status':status,'regressions':regressions,'unresolved':len(unresolved),'reduction':w['reduction'],'known_measurement_tokens':known_total,'usage':usage},indent=2))
