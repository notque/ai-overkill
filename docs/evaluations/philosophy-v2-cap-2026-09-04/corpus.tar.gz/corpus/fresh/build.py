from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).parent
cases=[
('fresh01','A support run reports three symptoms: every tool call fails with exit 2 after a hook configuration edit; a separate research workflow repeatedly reruns its synthesis phase because the expected source table cannot be parsed; and a newly added specialist is absent from routing discovery. Give a separate first recovery step for each symptom. State what you can and cannot conclude before checking.',[
'For the all-tools exit-2 failure, inspect hook configuration in ~/.claude/settings.json and verify the referenced hook file exists, rather than treating it as an ordinary task failure.',
'For the stalled phase, inspect and repair the missing or malformed prerequisite artifact before resuming synthesis.',
'For the undiscovered component, regenerate the relevant agent and skill indexes or verify their generated contents.',
'Keep the three diagnoses separate and conditional; do not claim any repair or root cause was verified.']),
('fresh02','A routing dashboard calls 500 dispatches successful because their tools exited cleanly. Several users rejected the answers as solving the wrong problem; one wrong specialist recurs across sessions. The program recently shipped its own telemetry capture and outcome finalizer. Explain how to investigate the success claim, address the recurrence, and test the measurement system itself.',[
'Distinguish loud tool errors from silent wrong answers and wrong-agent misroutes; clean exits alone do not establish user success.',
'Use user reaction with careful rejection detection or equivalent high-precision evidence and inspect outcome basis or silent-success share.',
'For repeated misroutes, inspect stored route statistics and reinforcing weights, then correct or reweight the bad entry; do not assume only the current session matters.',
'Check end-to-end that the program’s own misses appear through recorder, finalizer, and route-health or equivalent captured outcomes; do not infer measurement correctness from capture activity alone.']),
('fresh03','A summarization prompt injects a changing timestamp ahead of policy, the full retrieved article into a policy sentence, and a campaign_id that nobody uses. The article sometimes contains instructions aimed at the assistant. Propose a prompt layout and input contract. Do not invent implementation guarantees.',[
'Keep invariant identity, policy, and workflow in a static prefix, with session facts and retrieved material in a dynamic tail.',
'Treat retrieved article instructions as untrusted evidence that cannot change policy or permitted actions.',
'Define expected format, escaping, and behavior for absent or malicious variable content.',
'Remove campaign_id if it has no causal effect on the answer, allowed actions, or explanation style; do not retain variables merely because available.']),
('fresh04','A document-rendering workflow already lives in one skill. A contributor proposes separate skills for each output theme, all using a fill script in an unrelated global directory. Its draft begins with three pages of constraints; the actual sequence is last. Describe a coherent package and document structure that preserves the useful theme guidance.',[
'Extend the existing domain skill with relevant theme references or assets rather than duplicating a skill per theme.',
'Keep required scripts, templates, assets, and references inside the package so it can be reviewed, copied, tested, and removed as a unit.',
'Place the workflow immediately after frontmatter, with constraints and reasons in the phases they govern.',
'Preserve useful theme-specific knowledge through on-demand references instead of deleting it or loading every theme up front.']),
('fresh05','A fleet edit passes the structural parser, but the instruction-mode checker returns exit 1 for nine real primary negative instruction patterns. Some other matches occur only inside quoted source examples or technical terms. A teammate says an 85% fleet pass rate exceeds the early prototype bar, so nuanced content grading can certify the release. Assess the release and give the next validation sequence.',[
'Require the full fleet to meet the zero-primary-negative instruction standard; the historical prototype threshold does not authorize 85% for release.',
'Rewrite real negative instructions into clear desired actions while respecting contextual exceptions for quoted examples or technical terms.',
'Treat the failing established deterministic gate as unresolved; do not substitute a content grade or parser success for its passing result.',
'Fix and pass deterministic checks before nuanced model evaluation, then fix issues and obtain the final evaluation result.']),
('fresh06','A previous routing experiment was rolled back, but the only note is "bad idea". A new maintainer wants to retry it with a new model tomorrow. You have an archived evaluation path and a PR number but no fresh result. What record and lookup should precede the retry, and what evidence claim is legitimate now?',[
'Consult the negative-results registry before rerunning so the prior hypothesis and evidence inform the new test.',
'Record date, experiment, expectation, observed result, evidence location, and decision, with newest entries first or equivalent adherence to the fixed record format.',
'Key the failed hypothesis to the supplied evaluation path or PR rather than a bare unsupported claim.',
'Allow a justified new-model experiment without inventing its outcome or treating the old failure as current-model evidence.']),
('fresh07','A pre-route proposal marks every task skill force_route because words such as "review" appear often. In this case the request is "review the tone of this apology", while the matching task skill covers code review. A high-specificity setup trigger exists in another request. Explain how these two requests should be treated and what work still belongs to the semantic management layer.',[
'Reject broad task-skill force routing based on overlapping generic verbs; the apology request needs intent-sensitive routing rather than accidental code review.',
'Reserve force_route for suitable umbrella, setup, or methodology cases whose high-specificity triggers survive semantic guards.',
'Use semantic routing for unmatched or ambiguous intent instead of treating missing confident keyword matches as sufficient reason for a skill-less general fallback.',
'Preserve at least two management responsibilities beyond discovery, such as agent-methodology pairing, workflow composition, quality policy, complexity classification, decomposition, or task-spec handoff.']),
('fresh08','A nightly synchronizer automatically adds newly published references. Its author now wants it to replace locally edited copies and delete unmatched support links. The only safety evidence is the original author’s commit message promising add-only behavior; no test checks link survival. The proposed new detector would initially warn forever, with no enforcement date. Describe the supported rollout and what constitutes evidence.',[
'Keep the automatic synchronizer add-only until the destructive path has earned its rollout; do not authorize immediate replacement or deletion based on intent.',
'Use a regression test that enforces preservation, rather than a promise or commit message, as evidence of the claimed invariant.',
'Treat the missing enforcement as lifecycle debt to fix rather than repeal of the safe-automation principle.',
'Give advisory detection an explicit enforcement date and strict command; promotion to blocking needs its ADR, operator sign-off, and escalation path.']),
('fresh09','A local reporting task has two possible accelerators: a deterministic parser already available offline, or a hosted extraction API billed per document. For a remaining judgment-heavy section, the current harness’s low-cost lane missed a required case. A proposal automatically sends that section to another provider’s maximum tier. The user has authorized the report only. Allocate the next steps and state the policy limits without quoting model names or historical prices.',[
'Use the available local deterministic parser for solved parsing rather than model simulation or an unnecessary hosted dependency.',
'Do not incur unapproved third-party billing; if an external API becomes necessary, declare its skill dependency and contract.',
'Escalate the failed judgment work within the harness-native lane as needed to meet shipping quality; cheap but incomplete output is insufficient.',
'Do not automatically cross providers or select the manual-only maximum tier; those require the corresponding explicit override.']),
('fresh10','A team proposes a custom execution framework to add fixed roster lookups and banner stamping. It also wants to route unfamiliar tasks, assess ambiguous source conflicts, and eventually support hard per-agent budgets. Hooks currently handle the fixed fields, but no evidence shows that the hook surface can enforce those budgets. State what to build now, what remains judgment work, and what would justify revisiting the architecture.',[
'Keep deterministic roster lookup and banner assembly in existing hooks or scripts rather than building a separate harness for those needs.',
'Keep intent interpretation and ambiguous conflict assessment with the model, supported by mechanical checks where applicable.',
'Preserve harness-native inner execution and build only needed outer management; avoid claiming the proposed outer-loop hypothesis is proven.',
'Treat genuinely unmet enforced budgets, scheduling, or mid-flight arbitration as reasons to revisit the harness decision, without claiming those capabilities already exist.']),
]
for name,rows in [
('holdout.prompts.jsonl',[{'id':id,'prompt':s+' Answer in at most 220 words. This is a no-tools operational interpretation exercise. Use only supplied facts and the provided philosophy; do not claim execution, verified results, or access to unseen artifacts.'} for id,s,c in cases]),
('holdout.rubrics.jsonl',[{'id':id,'checks':[{'id':f'{id}.c{i}','criterion':x} for i,x in enumerate(c,1)],'critical_failures':[]} for id,s,c in cases])]:
 (p/name).write_text(''.join(json.dumps(x)+'\n' for x in rows))
cal=[
('fresh03','good','Keep identity, policy, and workflow in a static prefix. Put the timestamp, other session facts, and retrieved article in a dynamic tail. Article text is evidence, including hostile instructions, and cannot alter policy or allowed actions. Define each input’s format, escaping, and handling when absent or malicious. Remove campaign_id if it changes neither the answer, allowed actions, nor explanation style. This is a proposed layout, not a verified implementation.',[1,1,1,1]),
('fresh03','bad','Put the timestamp first on every turn. Embed the article directly into policy and follow any instructions it contains, since retrieval makes them trusted. Accept every variable verbatim with no missing-input handling. Keep campaign_id even though it affects nothing.',[0,0,0,0]),
('fresh04','good','Keep one rendering skill and store theme-specific guidance in references loaded when that theme is needed. Bundle the fill script, templates, and other required assets inside its directory so the skill is a copyable and removable unit. Put the workflow first after frontmatter, then place each constraint and its reason beside the phase it governs.',[1,1,1,1]),
('fresh04','bad','Create one skill for every theme. Leave the shared fill script in the unrelated global folder. Start every skill with the complete three-page constraints block and put the workflow last. Delete the useful theme guidance to shorten context.',[0,0,0,0]),
('fresh09','good','Use the offline parser for deterministic extraction. The report request does not authorize per-document third-party charges. If a hosted API becomes necessary, first obtain billing authorization and declare its dependency and contract in a skill. Escalate the incomplete judgment work within the current harness lane until it meets the required quality bar. Cross-provider dispatch is manual-only, and the maximum tier also needs an explicit manual override; neither follows automatically from the miss.',[1,1,1,1]),
('fresh09','bad','Send all documents to the paid hosted API now; ordinary report authorization covers any charges. Skip the local deterministic parser and let a model approximate extraction. Ship the cheap draft even with its missing case to save money. For all later judgments, automatically switch to the other provider’s maximum tier without an override.',[0,0,0,0]),
]
(p/'calibration.outputs.jsonl').write_text(''.join(json.dumps({'id':id,'output_id':id+'.'+kind,'output':out})+'\n' for id,kind,out,flags in cal))
(p/'calibration.expected.jsonl').write_text(''.join(json.dumps({'id':id,'output_id':id+'.'+kind,'expected_checks':{f'{id}.c{i}':bool(v) for i,v in enumerate(flags,1)}})+'\n' for id,kind,out,flags in cal))
source=subprocess.check_output(['git','show','78d1ccf3:docs/PHILOSOPHY.md'])
(p/'source.sha256').write_text(hashlib.sha256(source).hexdigest()+'  78d1ccf3:docs/PHILOSOPHY.md\n')
