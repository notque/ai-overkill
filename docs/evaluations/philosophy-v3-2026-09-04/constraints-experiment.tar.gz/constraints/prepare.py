import hashlib,json,pathlib,shutil
R=pathlib.Path('/tmp/vexjoy-philosophy-output-constraints');V3=pathlib.Path('/tmp/vexjoy-philosophy-v3-trial');C=pathlib.Path('/tmp/vexjoy-output-constraints-corpus')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
for d in ('harness','inputs','private','rubrics','originals'):(R/d).mkdir(exist_ok=True)
assert sha(C/'SHA256SUMS')=='64dfe4501527d0457c8eb77c0f673fd936c515e07a03def42b0aebc766e328d0'
for line in (C/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split(maxsplit=1);p=pathlib.Path(name.lstrip('*'));p=p if p.is_absolute() else C/p;assert sha(p)==digest
for name in ('runner.py','judge.py','assess.py','process_control.py'):shutil.copyfile(V3/'harness'/name,R/'harness'/name)
shutil.copyfile(R/'harness/runner.py',R/'originals/runner-json.py')
p=R/'harness/runner.py';s=p.read_text();assert s.count('and isinstance(answer, dict)')==1;s=s.replace('and isinstance(answer, dict)','and bool(final)')
old='''    try:
        answer = json.loads(final)
        valid_answer = isinstance(answer, dict)
    except json.JSONDecodeError:
        answer, valid_answer = None, False
''';new='''    try:
        answer = json.loads(final)
    except json.JSONDecodeError:
        answer = None
    # Native task output is data; the task-specific validator checks its shape.
    valid_answer = bool(final)
''';assert old in s;s=s.replace(old,new).replace('timeout=min(protocol.get("timeout_seconds", 180), 180)','timeout=min(protocol.get("timeout_seconds", 300), 300)');p.write_text(s)
for name in ('baseline.md','challenger.md'):shutil.copyfile(V3/'inputs'/name,R/'inputs'/name)
shutil.copyfile(C/'validate.py',R/'harness/validate_constraints.py');shutil.copyfile(C/'PROTOCOL.md',R/'originals/corpus-PROTOCOL.md');shutil.copyfile(C/'SHA256SUMS',R/'originals/corpus-SHA256SUMS')
(R/'inputs/contract.txt').write_text('Use the supplied design philosophy to guide your answer to the user\'s writing task. Follow the task\'s native output contract exactly. Do not use tools.\n')
cases=[];mapping={};rubrics=[];source_rubrics={r['id']:r for r in rows(C/'tasks.rubrics.jsonl')}
for i,c in enumerate(rows(C/'tasks.prompts.jsonl'),1):
 uid=f'constraint{i:02d}';filename='inputs/'+uid+'.txt';(R/filename).write_text(c['prompt']+'\n');cases.append({'id':uid,'suite':'dev','prompt_file':filename});mapping[uid]=c['id'];r=source_rubrics[c['id']];rubrics.append({'id':uid,'checks':[{**x,'id':uid+f'.c{j+1}'} for j,x in enumerate(r['checks'])],'critical_failures':r['critical_failures']})
write(R/'cases.json',cases);write(R/'private/case-map.json',mapping);(R/'rubrics/all.rubrics.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in rubrics));inverse={v:k for k,v in mapping.items()};rubricmap={r['id']:r for r in rubrics};expected={r['output_id']:r for r in rows(C/'calibration.expected.jsonl')};packets=[];calmap={}
for c in rows(C/'calibration.outputs.jsonl'):
 uid=hashlib.sha256(('nativeconstraint-v1:'+c['output_id']).encode()).hexdigest()[:24];cid=inverse[c['id']];r=rubricmap[cid];packets.append({'id':uid,'request':(R/'inputs'/(cid+'.txt')).read_text().rstrip('\n'),'context':'','response':c['output'],'rubric':{'checks':r['checks'],'critical_failures':r['critical_failures']}});old=source_rubrics[c['id']];e=expected[c['output_id']];calmap[uid]={'source_case_id':c['id'],'expected_format_pass':e['expected_format_pass'],'expected_checks':{r['checks'][i]['id']:int(e['expected_checks'][oc['id']]) for i,oc in enumerate(old['checks'])},'expected_critical_violation':e['expected_critical_violation']}
serialized=''.join(json.dumps(p)+'\n' for p in packets);assert '.good' not in serialized and '.bad' not in serialized;(R/'calibration-packets.jsonl').write_text(serialized);write(R/'private/calibration-map.json',calmap)
protocol={'version':1,'model':'gpt-6-astra','effort':'low','seed':49102026,'repeats':5,'timeout_seconds':300,'worker_concurrency':4,'judge_concurrency':4,'cases_file':'cases.json','arms':{'baseline':{'instruction_file':'inputs/baseline.md'},'challenger':{'instruction_file':'inputs/challenger.md'}},'common_context_files':['inputs/contract.txt'],'candidate_sha256':sha(R/'inputs/challenger.md'),'baseline_source':'78d1ccf3:docs/PHILOSOPHY.md','case_count':6,'worker_count':60,'source_corpus_manifest_sha256':sha(C/'SHA256SUMS'),'source_harness_commit':'902fa453ca683118cffc9727c8b68418486b4018','native_output_adapter':'Remove generic JSON-object success requirement only; require captured nonempty final text plus unchanged raw event/usage/no-tools/final-identity checks. Deterministic corpus validator grades native shape. Preserve parsed JSON helper where applicable. Set worker timeout300seconds as frozen.','generation_token_cap':{'configured':False,'value':None,'reason':'Installed CodexCLI exposes no verified per-generation cap; do not pretend one is pinned. Backend default unknown. Same model/effort/client/settings botharms, natural output budgets in tasks, timeout300seconds. Record truncation or missing completion as failure, never replace silently.'},'grading':'All60outputs retained. Deterministic validator exact sourcecopy on each. Two blind semantic passes after exact12control calibration. Mechanical outcomes hidden from semanticjudges. Resolve disputedchecks/criticals with independent masked adjudication, preserve bothvotes, lock before unmasking. Critical/check inconsistency must be investigated blind.','floor':'For each6cases, candidate must not decrease5-output format-pass count, any of3 individual semantic-check passcounts, or joint(format ANDallsemantics)passcount. Wherever baseline zero criticalformat or criticalsemantic failures, candidate must havezero samekind. Baseline failures stay in denominator. Unresolved disagreement=inconclusive. Failed generation remains failed output in assigned denominator; unknownusage blocks costconclusion.','cost':'No cost-saving target from this corpus; reportall60calls and evaluator/calibration/invalid spend; no silent exclusions.','promotion':'Eligibility only on realoutputconstraints; separate V3meaningdev,fresh,pooledcost+semanticgates and authorizedreview/CI remain mandatory. No philosophyPRmerge on meaningalone.','prior_disclosure':'Corpusauthor had selected6taskclasses before unsolicited aggregateV2cap counts; no candidate/taskresponses seen; corpus provenance explicitly records disclosure. No further outcome or comparison sent to author.','calibration':'All12frozencontrols, opaqueIDs, two exact semanticpasses plus deterministic expectedformat check; no good/bad sourceIDs passed.','retries':'No automatic or selective retry. Preserve invalidattempts/unknownusage. Any whole-campaign infrastructure restart requires separatepriorauthorization.'}
write(R/'protocol.json',protocol);write(R/'adapter-source-map.json',{'original_runner_sha256':sha(R/'originals/runner-json.py'),'native_runner_sha256':sha(R/'harness/runner.py'),'other_harness_hashes':{p.name:sha(p) for p in (R/'harness').glob('*.py') if p.name!='runner.py'}})
print(json.dumps({'protocol_sha256':sha(R/'protocol.json'),'native_runner_sha256':sha(R/'harness/runner.py'),'cases':len(cases),'controls':len(packets)}))
