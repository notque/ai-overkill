#!/usr/bin/env python3
"""Deterministic constraints only; semantic grades are a separate blind assessment."""
import argparse,json,sys

def validate(case_id,raw):
    # A transport-added terminal LF or CRLF is ignored once. Every other byte counts.
    s=raw[:-2] if raw.endswith('\r\n') else raw[:-1] if raw.endswith('\n') else raw
    line_breaks='\n\r\v\f\x1c\x1d\x1e\x85\u2028\u2029'
    errors=[]
    metrics={'unicode_code_points':len(s),'utf8_bytes':len(s.encode('utf-8')),'words':len(s.split())}
    if not s: errors.append('empty output')
    if case_id=='json_status':
        def unique(pairs):
            d={}
            for k,v in pairs:
                if k in d: raise ValueError('duplicate JSON key')
                d[k]=v
            return d
        try:
            obj=json.loads(s,object_pairs_hook=unique)
            if not isinstance(obj,dict) or set(obj)!={'status','summary','next_action'}: errors.append('expected exactly the three specified object keys')
            if isinstance(obj,dict):
                if not all(isinstance(v,str) for v in obj.values()): errors.append('all values must be strings')
                if obj.get('status')!='blocked': errors.append('status must equal blocked')
        except (ValueError,TypeError): errors.append('invalid single JSON object')
    elif case_id=='ui_tooltip':
        if any(x in s for x in line_breaks): errors.append('must be one line')
        if len(s)>90: errors.append('exceeds 90 Unicode code points')
    elif case_id=='three_bullets':
        lines=s.split('\n')
        if len(lines)!=3 or any(not x.startswith('- ') or not x[2:].strip() or any(c in x for c in line_breaks) for x in lines): errors.append('expected exactly three nonempty - bullet lines')
    elif case_id=='one_sentence':
        if any(x in s for x in line_breaks): errors.append('must be one line')
        if not s.endswith('.') or s.count('.')!=1 or any(x in s for x in ['?','!','…']): errors.append('expected one terminal period and no other sentence-ending punctuation')
    elif case_id=='release_note':
        if len(s.split())>40: errors.append('exceeds 40 whitespace-separated words')
    elif case_id=='form_note':
        if '\t' in s or any(x in s for x in line_breaks): errors.append('tabs and line breaks forbidden')
        if len(s.encode('utf-8'))>160: errors.append('exceeds 160 UTF-8 bytes')
    else: raise ValueError('unknown case '+case_id)
    return {'id':case_id,'format_pass':not errors,'errors':errors,'metrics':metrics}

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('jsonl',help='Rows with id and output; output_id is optional')
    args=parser.parse_args()
    with open(args.jsonl) as f:
        for line in f:
            row=json.loads(line); result=validate(row['id'],row['output'])
            if 'output_id' in row: result['output_id']=row['output_id']
            print(json.dumps(result))
