import collections,hashlib,json,pathlib,sys
R=pathlib.Path(__file__).parent;sys.path.insert(0,str(R/'harness'))
import runner,judge,assess,validate_constraints

def read(p):return json.loads(p.read_text())
def lines(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def calibration():
 root=R/'calibration-judges';summary=read(root/'summary.json');expected=read(R/'private/calibration-map.json');packets=lines(R/'calibration-packets.jsonl');lookup={p['id']:p for p in packets};errors=[];scores=[];usage=collections.Counter();assert read(root/'manifest.json')['packets']==packets
 for path in root.glob('pass-*/result.json'):
  result=read(path);folder=path.parent
  if not result['valid']:errors.append({'batch':folder.name,'error':result.get('error')});continue
  assert judge.parse_events((folder/'events.jsonl').read_text())==result['usage'];usage.update(result['usage']);final=read(folder/'final.json');events=lines(folder/'events.jsonl');messages=[e['item']['text'] for e in events if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='agent_message'];assert json.loads(messages[-1])==final
  ps=[lookup[x] for x in result['packet_ids']];judgments=judge.validate(final,ps);assert judgments==result['judgments'];assert (folder/'prompt.txt').read_text()==judge.INSTRUCTION+'\nPACKETS:\n'+json.dumps(ps,ensure_ascii=False)
  for j in judgments:
   e=expected[j['id']];actual={c['id']:c['score'] for c in j['checks']};critical=any(c['violated'] for c in j['critical_violations']);fmt=validate_constraints.validate(e['source_case_id'],lookup[j['id']]['response'])['format_pass']
   if actual!=e['expected_checks'] or critical!=e['expected_critical_violation'] or fmt!=e['expected_format_pass']:errors.append({'id':j['id'],'pass':result['pass'],'actual_checks':actual,'actual_critical':critical,'actual_format':fmt,'expected':e})
   scores.append((j['id'],result['pass']))
 assert len(scores)==len(set(scores));complete=set(scores)=={(p['id'],i) for p in packets for i in (1,2)};v={'valid':summary['valid'] and complete and not errors,'controls':12,'passes':2,'judgments':len(scores),'errors':errors,'usage':dict(usage),'total_tokens':usage['input_tokens']+usage['output_tokens']};write(R/'calibration-verdict.json',v);print(json.dumps(v));return v['valid']
def workers():
 _,_,cases,records=assess.records(R/'results','all');assert len(cases)==6 and len(records)==60;mapping=read(R/'private/case-map.json');inventory=[];usage=collections.Counter();unknown=[]
 for a,r,task in records:
  fmt=validate_constraints.validate(mapping[a['case_id']],r['last_message']);inventory.append({'assignment':a,'raw_valid':r['success'],'native_output':r['last_message'],'format_result':fmt,'effective_format_pass':r['success'] and fmt['format_pass'],'usage':r['usage'],'usage_known':r['usage_known']})
  if r['usage_known']:usage.update(r['usage'])
  else:unknown.append(a['uid'])
 report={'worker_count':60,'raw_valid':sum(x['raw_valid'] for x in inventory),'format_passes':sum(x['effective_format_pass'] for x in inventory),'unknown_usage':unknown,'usage':dict(usage),'total_tokens':usage['input_tokens']+usage['output_tokens']};write(R/'private/inventory.json',inventory);write(R/'worker-report.json',report);print(json.dumps(report));return True
def disputes():
 private=read(R/'private/judge-map.json');packets=[private['packets'][p]['packet'] for p in private['packet_order']];rows=assess.verified_judgments(R/'judges',packets,private['judge_config']);by=collections.defaultdict(list)
 for row in rows:by[row['id']].append(row)
 ds=[]
 for p in packets:
  votes=by[p['id']];assert len(votes)==2;a,b=[{c['id']:c['score'] for c in v['checks']} for v in votes];critical=[any(c['violated'] for c in v['critical_violations']) for v in votes];ids=[cid for cid in a if a[cid]!=b[cid]];inconsistent=any(any(c['score']==0 for c in v['checks'])!=crit for v,crit in zip(votes,critical))
  if ids or critical[0]!=critical[1] or inconsistent:ds.append({**p,'disputed_checks':ids,'critical_disagreement':critical[0]!=critical[1],'critical_check_inconsistency':inconsistent,'votes':votes})
 write(R/'disputed-blind.json',ds);write(R/'private/verified-judge-rows.json',rows);print(json.dumps({'packets':len(packets),'disputed_packets':len(ds),'sha256':hashlib.sha256((R/'disputed-blind.json').read_bytes()).hexdigest()}));return True
def score():
 private=read(R/'private/judge-map.json');packets=[private['packets'][x]['packet'] for x in private['packet_order']];rows=assess.verified_judgments(R/'judges',packets,private['judge_config']);by=collections.defaultdict(list)
 for row in rows:by[row['id']].append(row)
 ds=read(R/'disputed-blind.json');needs={p['id']:p for p in ds};resolved={};ap=R/'adjudications.json'
 if ap.exists():
  lock=read(R/'adjudication-lock.json');assert lock['locked_before_arm_reveal'] and hashlib.sha256(ap.read_bytes()).hexdigest()==lock['sha256']
  for x in read(ap)['adjudications']:
   assert x['id'] in needs and x['id'] not in resolved;assert x['evidence'].strip() and x['rationale'].strip();resolved[x['id']]=x
 inventory={x['assignment']['uid']:x for x in read(R/'private/inventory.json')};counts=collections.defaultdict(lambda:{'format':0,'checks':collections.Counter(),'joint':0,'critical_format':0,'critical_semantic':0,'outputs':0});unresolved=[];rowreport=[]
 for p in packets:
  votes=by[p['id']];a=private['packets'][p['id']]['assignment'];actual={c['id']:c['score'] for c in votes[0]['checks']};crit=any(c['violated'] for c in votes[0]['critical_violations'])
  if p['id'] in needs:
   if p['id'] not in resolved:unresolved.append(p['id']);continue
   x=resolved[p['id']];assert set(x['checks'])==set(actual);assert all(type(v) is int and v in (0,1) for v in x['checks'].values());assert type(x['critical_violation']) is bool
   # Check changes require a vote dispute or explicit critical/check inconsistency.
   disputed=set(needs[p['id']]['disputed_checks']);inconsistent=needs[p['id']]['critical_check_inconsistency']
   for cid,score in actual.items():
    if cid not in disputed and not inconsistent:assert x['checks'][cid]==score
   actual=x['checks'];crit=x['critical_violation']
  if any(v==0 for v in actual.values())!=crit:unresolved.append(p['id']);continue
  inv=inventory[a['uid']];valid=inv['raw_valid'];eff={cid:v if valid else 0 for cid,v in actual.items()};fmt=inv['effective_format_pass'];effcrit=crit or not valid;c=counts[(a['case_id'],a['arm'])];c['outputs']+=1;c['format']+=fmt;c['checks'].update(eff);c['joint']+=fmt and all(eff.values());c['critical_format']+=not fmt;c['critical_semantic']+=effcrit;rowreport.append({'id':p['id'],'assignment':a,'raw_valid':valid,'format_pass':fmt,'original_checks':actual,'effective_checks':eff,'critical_semantic':effcrit,'native_output':inv['native_output']})
 caseids=sorted({x['case_id'] for x in [v['assignment'] for v in private['packets'].values()]});assert len(caseids)==6;regressions=[];case_report=[]
 for cid in caseids:
  b,c=counts[(cid,'baseline')],counts[(cid,'challenger')];checks=sorted({x['id'] for p in packets if private['packets'][p['id']]['assignment']['case_id']==cid for x in p['rubric']['checks']});complete=b['outputs']==c['outputs']==5
  reasons=[]
  if complete:
   if c['format']<b['format']:reasons.append('format pass count declined')
   reasons+=['semantic check declined: '+k for k in checks if c['checks'][k]<b['checks'][k]]
   if c['joint']<b['joint']:reasons.append('joint pass count declined')
   for kind in ('critical_format','critical_semantic'):
    if b[kind]==0 and c[kind]>0:reasons.append('new '+kind+' where baseline zero')
  if reasons:regressions.append(cid)
  case_report.append({'id':cid,'baseline':dict(b),'challenger':dict(c),'reasons':reasons,'complete':complete})
 report=read(R/'worker-report.json');cal=read(R/'calibration-verdict.json');status='INCONCLUSIVE' if unresolved else 'REJECT' if regressions or not cal['valid'] else 'ELIGIBLE_ON_OUTPUT_CONSTRAINTS_ONLY';v={'status':status,'workers':60,'case_counts':case_report,'regressions':regressions,'unresolved':unresolved,'row_evidence':rowreport,'worker_usage':report,'cost_conclusions_valid':not report['unknown_usage'],'production_authorized':False,'separate_meaning_cost_gates_required':True};write(R/'VERDICT.json',v);print(json.dumps({'status':status,'regressions':regressions,'unresolved':len(unresolved)}));return status=='ELIGIBLE_ON_OUTPUT_CONSTRAINTS_ONLY'
if __name__=='__main__':raise SystemExit(0 if {'calibration':calibration,'workers':workers,'disputes':disputes,'score':score}[sys.argv[1]]() else 1)
