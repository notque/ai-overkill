import collections,hashlib,json,pathlib,statistics,sys
from fractions import Fraction
R=pathlib.Path(__file__).parent;sys.path.insert(0,str(R/'harness'))
import runner,judge,assess

def read(p):return json.loads(p.read_text())
def lines(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def calibration():
 root=R/'calibration-judges';summary=read(root/'summary.json');expected=read(R/'private/calibration-map.json');packets=lines(R/'calibration-packets.jsonl');lookup={p['id']:p for p in packets};errors=[];scores=[];usage=collections.Counter()
 assert read(root/'manifest.json')['packets']==packets
 for batch in root.glob('pass-*/result.json'):
  result=read(batch);folder=batch.parent
  if not result['valid']:errors.append({'batch':folder.name,'error':result.get('error')});continue
  raw=(folder/'events.jsonl').read_text();assert judge.parse_events(raw)==result['usage'];usage.update(result['usage'])
  final=read(folder/'final.json');events=lines(folder/'events.jsonl');messages=[e['item']['text'] for e in events if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='agent_message'];assert json.loads(messages[-1])==final
  ps=[lookup[x] for x in result['packet_ids']];judgments=judge.validate(final,ps);assert judgments==result['judgments'];assert (folder/'prompt.txt').read_text()==judge.INSTRUCTION+'\nPACKETS:\n'+json.dumps(ps,ensure_ascii=False)
  for j in judgments:
   actual={c['id']:c['score'] for c in j['checks']}
   if actual!=expected[j['id']]['expected_checks'] or any(c['violated'] for c in j['critical_violations']):errors.append({'id':j['id'],'pass':result['pass'],'actual':actual,'expected':expected[j['id']]['expected_checks']})
   scores.append((j['id'],result['pass']))
 assert len(scores)==len(set(scores));complete=set(scores)=={(p['id'],i) for p in packets for i in (1,2)}
 verdict={'valid':summary['valid'] and complete and not errors,'controls':6,'passes':2,'judgments':len(scores),'exact':not errors,'errors':errors,'usage':dict(usage),'total_tokens':usage['input_tokens']+usage['output_tokens']}
 write(R/'calibration-verdict.json',verdict);print(json.dumps(verdict));return verdict['valid']
def workers(suite):
 manifest,protocol,cases,records=assess.records(R/'results',suite);selected={a['case_id'] for a,_,_ in records};expected={'dev':(30,300),'holdout':(10,100),'all':(40,400)}[suite];assert(len(selected),len(records))==expected
 samples=collections.defaultdict(list);usage=collections.Counter();failures=[];compliance=[];unknown=[]
 for a,r,_ in records:
  if not r['success']:failures.append({'uid':a['uid'],'case_id':a['case_id'],'arm':a['arm'],'runtime_errors':r['runtime_errors'],'timed_out':r['timed_out']})
  shaped=isinstance(r['answer'],dict) and set(r['answer'])=={'answer'} and isinstance(r['answer']['answer'],str)
  compliance.append({'uid':a['uid'],'case_id':a['case_id'],'arm':a['arm'],'answer_shape_valid':shaped,'words':len(r['answer']['answer'].split()) if shaped else None})
  if r['usage_known']:
   u=r['usage'];usage.update(u);samples[(a['arm'],a['repeat'])].append(u['input_tokens']+u['output_tokens'])
  else:unknown.append(a['uid'])
 complete=all(len(samples[(arm,i)])==expected[0] for arm in ('baseline','challenger') for i in range(5));medians={arm:[statistics.median(samples[(arm,i)]) if samples[(arm,i)] else None for i in range(5)] for arm in ('baseline','challenger')}
 pooled={arm:[t for i in range(5) for t in samples[(arm,i)]] for arm in ('baseline','challenger')};b,c=[statistics.median(pooled[arm]) if pooled[arm] else None for arm in ('baseline','challenger')];spread=max(medians['baseline'])-min(medians['baseline']) if all(v is not None for v in medians['baseline']) else None;saving=b-c if b is not None and c is not None else None
 report={'suite':suite,'workers':expected[1],'cases':expected[0],'raw_valid':not failures,'failures':failures,'token_denominator_complete':complete,'unknown_usage_assignments':unknown,'baseline_corpusmedians':medians['baseline'],'challenger_corpusmedians':medians['challenger'],'baseline_pooled_median':b,'challenger_pooled_median':c,'saving':saving,'reduction':saving/b if b else None,'baseline_spread':spread,'variance_threshold':2*spread if spread is not None else None,'token_target_passes':complete and saving/b>=.2 and saving>2*spread,'usage':dict(usage),'total_tokens':usage['input_tokens']+usage['output_tokens'],'output_compliance':{'shape_violations':sum(not x['answer_shape_valid'] for x in compliance),'word_counts_are_descriptive_only':True,'generic_word_limit_gate':False}}
 write(R/suite/'worker-report.json',report);write(R/suite/'output-compliance.json',compliance);print(json.dumps(report));return not failures and complete
def disputes(suite):
 d=R/suite;private=read(d/'private/judge-map.json');packets=[private['packets'][p]['packet'] for p in private['packet_order']];rows=assess.verified_judgments(d/'judges',packets,private['judge_config']);by=collections.defaultdict(list)
 for row in rows:by[row['id']].append(row)
 disputed=[]
 for p in packets:
  votes=by[p['id']];assert len(votes)==2;a,b=[{c['id']:c['score'] for c in v['checks']} for v in votes];ids=[cid for cid in a if a[cid]!=b[cid]]
  criticaldiff={c['criterion']:c['violated'] for c in votes[0]['critical_violations']}!={c['criterion']:c['violated'] for c in votes[1]['critical_violations']}
  if ids or criticaldiff:disputed.append({**p,'disputed_checks':ids,'critical_disagreement':criticaldiff,'votes':votes})
 write(d/'disputed-blind.json',disputed);write(d/'private/verified-judge-rows.json',rows);print(json.dumps({'packets':len(packets),'judgments':len(rows),'disputed_packets':len(disputed),'disputed_checks':sum(len(p['disputed_checks']) for p in disputed),'sha256':hashlib.sha256((d/'disputed-blind.json').read_bytes()).hexdigest()}));return True
def score(suite):
 d=R/suite;private=read(d/'private/judge-map.json');packets=[private['packets'][x]['packet'] for x in private['packet_order']];rows=assess.verified_judgments(d/'judges',packets,private['judge_config']);by=collections.defaultdict(list)
 for row in rows:by[row['id']].append(row)
 ds=read(d/'disputed-blind.json');need={(p['id'],c) for p in ds for c in p['disputed_checks']};resolved={};path=d/'adjudications.json'
 if path.exists():
  lock=read(d/'adjudication-lock.json');assert hashlib.sha256(path.read_bytes()).hexdigest()==lock['sha256'];assert lock['locked_before_arm_reveal'] is True
  for r in read(path)['adjudications']:
   k=(r['id'],r['check_id']);assert k in need and k not in resolved;assert type(r['score']) is int and r['score'] in (0,1);assert r['evidence'].strip() and r['rationale'].strip();resolved[k]=r['score']
 unresolved=need-set(resolved);utility=collections.defaultdict(list);critical=collections.defaultdict(int);critical_disagreements=[]
 for p in packets:
  votes=by[p['id']];assert len(votes)==2;a=private['packets'][p['id']]['assignment'];v1,v2=[{c['id']:c['score'] for c in v['checks']} for v in votes];scores={}
  for cid in v1:
   if v1[cid]==v2[cid]:scores[cid]=v1[cid]
   elif (p['id'],cid) in resolved:scores[cid]=resolved[(p['id'],cid)]
  if len(scores)==len(v1):utility[(a['case_id'],a['arm'])].append(Fraction(sum(scores.values()),len(scores)))
  lc,rc=[{c['criterion']:c['violated'] for c in v['critical_violations']} for v in votes]
  if lc!=rc:critical_disagreements.append(p['id'])
  else:critical[(a['case_id'],a['arm'])]+=sum(lc.values())
 ids=sorted({v['assignment']['case_id'] for v in private['packets'].values()});assert len(ids)=={'dev':30,'holdout':10}[suite];case_report=[];regressions=[]
 for cid in ids:
  exact={arm:sum(utility[(cid,arm)],Fraction(0))/5 if len(utility[(cid,arm)])==5 else None for arm in ('baseline','challenger')};reg=all(v is not None for v in exact.values()) and (exact['challenger']<exact['baseline'] or critical[(cid,'challenger')]>critical[(cid,'baseline')])
  if reg:regressions.append(cid)
  case_report.append({'id':cid,'exact_means':{a:str(v) if v is not None else None for a,v in exact.items()},'means':{a:float(v) if v is not None else None for a,v in exact.items()},'critical':{a:critical[(cid,a)] for a in exact},'regression':reg})
 w=read(d/'worker-report.json');cal=read(R/'calibration-verdict.json');status='INCONCLUSIVE' if unresolved or critical_disagreements else 'REJECT' if regressions or not w['raw_valid'] or not w['token_denominator_complete'] or not w['token_target_passes'] or not cal['valid'] else 'STAGE_PASS'
 verdict={'suite':suite,'status':status,'case_utility':case_report,'regressions':regressions,'unresolved_checks':sorted(unresolved),'unresolved_critical_packets':critical_disagreements,'token_metric':w,'calibration_valid':cal['valid'],'output_constraints_separate_promotion_prerequisite':True,'production_authorized':False};write(d/'VERDICT.json',verdict);print(json.dumps({'suite':suite,'status':status,'regressions':regressions,'unresolved':len(unresolved),'token_reduction':w['reduction']}));return status=='STAGE_PASS'
if __name__=='__main__':
 cmd=sys.argv[1];ok=calibration() if cmd=='calibration' else {'workers':workers,'disputes':disputes,'score':score}[cmd](sys.argv[2]);raise SystemExit(0 if ok else 1)
