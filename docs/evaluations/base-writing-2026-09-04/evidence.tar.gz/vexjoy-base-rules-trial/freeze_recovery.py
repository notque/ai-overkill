import hashlib,json
from datetime import datetime,timezone
from pathlib import Path
root=Path(__file__).parent;latest=root/'judges-rerun'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())
manifest=read(latest/'manifest.json');valid=[];failed=[]
for path in sorted(latest.glob('pass-*/result.json')):
 record=read(path);item={'batch':path.parent.name,'origin':str(path.parent),'artifact_sha256':{p.name:sha(p) for p in sorted(path.parent.iterdir()) if p.is_file()}}
 if record.get('valid') is True:valid.append(item)
 else:
  assert record.get('error')=='timeout' and record.get('usage') is None and record.get('judgments')==[]
  failed.append({**item,'pass':record['pass'],'packet_ids':record['packet_ids'],'fingerprint':record['fingerprint']})
assert len(valid)==71 and len(failed)==1
assert failed[0]['batch']=='pass-2-d239319cc0e49883'
decision={'created_utc':datetime.now(timezone.utc).isoformat(),'status':'PROPOSED_REQUIRES_INDEPENDENT_REVIEW_BEFORE_CALL',
 'authorization':'Parent explicitly permits ONE transport-only recovery proposal; evidence_audit approval required before call.',
 'latest_campaign_manifest_sha256':sha(latest/'manifest.json'),'original_inconclusive_report_sha256':sha(root/'REPORT.json'),
 'source_record_sha256':sha(root/'judge-rerun-source.json'),'packet_file_sha256':sha(root/'packets.jsonl'),
 'accepted_original_batches':valid,'eligible_missing_batch':failed[0],'max_fresh_attempts':1,
 'recovery_directory':str(root/'judge-single-recovery'),'assembled_directory':str(root/'judges-assembled'),
 'same_configuration':{key:manifest[key] for key in ('model','effort','instruction','schema','timeout','calibration')},
 'quality_and_token_policy':'Unchanged protocol.json plus previously frozen blind adjudication rule. No thresholds or rubrics changed.',
 'selection_rule':'Keep every valid latest-campaign batch unchanged. Only its single typed-timeout batch is eligible. Initial campaign votes excluded. Never select between valid votes. If recovery invalid or missing, stop inconclusive.',
 'provenance_rule':'Separate assembled directory; bind all accepted raw artifact hashes and origins plus recovery artifacts. Preserve every initial/fresh/recovery failure and known/unknown usage.',
 'arms_still_masked':True,'no_case_outcomes_inspected':True}
p=root/'SINGLE-RECOVERY-DECISION.json';assert not p.exists();p.write_text(json.dumps(decision,indent=2)+'\n');print(json.dumps({'decision':str(p),'sha256':sha(p),'valid_preserved':len(valid),'eligible_failed':len(failed)}))
