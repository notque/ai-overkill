"""One approved transport recovery; never replaces a valid vote or old artifact."""
import hashlib,json,shutil,sys
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'harness-rerun'))
import judge

def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def require(value,message):
 if not value:raise ValueError(message)
def write_new(path,value):
 with path.open('x') as f:f.write(json.dumps(value,indent=2)+'\n')
def check_origin(origin):
 directory=Path(origin['origin'])
 require({p.name for p in directory.iterdir() if p.is_file()}==set(origin['artifact_sha256']),'Origin artifact set changed')
 for name,expected in origin['artifact_sha256'].items():require(sha(directory/name)==expected,'Origin artifact changed: '+name)

def main():
 decision_path=ROOT/'SINGLE-RECOVERY-DECISION.json';decision=read(decision_path)
 limits=read(ROOT/'SINGLE-RECOVERY-LIMITS.json');approval=read(ROOT/'SINGLE-RECOVERY-APPROVAL.json')
 require(approval.get('approved') is True and approval.get('decision_sha256')==sha(decision_path)
         and approval.get('limits_sha256')==sha(ROOT/'SINGLE-RECOVERY-LIMITS.json'),'Missing matching independent approval')
 require(limits['driver_sha256']==sha(Path(__file__)),'Recovery driver changed')
 for name,expected in limits['source_sha256'].items():require(sha(ROOT/'harness-rerun'/name)==expected,'Recovery source changed')
 latest=ROOT/'judges-rerun';manifest=read(latest/'manifest.json')
 require(sha(latest/'manifest.json')==decision['latest_campaign_manifest_sha256'],'Latest manifest changed')
 require(sha(ROOT/'packets.jsonl')==decision['packet_file_sha256'],'Packets changed')
 require(sha(ROOT/'REPORT.json')==decision['original_inconclusive_report_sha256'],'Original report changed')
 require(judge.INSTRUCTION==decision['same_configuration']['instruction'] and judge.SCHEMA==decision['same_configuration']['schema'],'Judge instruction/schema changed')
 require(manifest['model']=='gpt-6-astra' and manifest['effort']=='low' and manifest['timeout']==300,'Configuration mismatch')
 for origin in decision['accepted_original_batches']+[decision['eligible_missing_batch']]:check_origin(origin)
 eligible=decision['eligible_missing_batch'];lookup={p['id']:p for p in manifest['packets']};batch=[lookup[x] for x in eligible['packet_ids']]
 fingerprint=judge.digest({'packets':batch,'instruction':judge.INSTRUCTION,'schema':judge.SCHEMA,'model':'gpt-6-astra','effort':'low','pass':eligible['pass']})
 require(fingerprint==eligible['fingerprint'],'Recovery packet fingerprint changed')
 recovery=Path(decision['recovery_directory']);recovery.mkdir(exist_ok=False)
 write_new(recovery/'manifest.json',{'decision_sha256':sha(decision_path),'approval_sha256':sha(ROOT/'SINGLE-RECOVERY-APPROVAL.json'),
  'limits_sha256':sha(ROOT/'SINGLE-RECOVERY-LIMITS.json'),'packets':batch,'pass':eligible['pass'],**decision['same_configuration']})
 write_new(recovery/'ATTEMPT-STARTED.json',{'attempt':1,'maximum':1,'fingerprint':fingerprint})
 result=judge.run_batch(eligible['pass'],batch,SimpleNamespace(out=recovery,timeout=300,calibration=False))
 if result.get('valid') is not True:
  write_new(recovery/'STOP-INCONCLUSIVE.json',{'reason':'Only recovery attempt invalid; no further retries.','result':result})
  print(json.dumps({'valid':False,'stop':'INCONCLUSIVE'}));return 1
 # Assemble a separate dataset; originals and failed attempts stay untouched.
 assembled=Path(decision['assembled_directory']);assembled.mkdir(exist_ok=False)
 origins=list(decision['accepted_original_batches'])
 source=recovery/eligible['batch'];origins.append({'batch':eligible['batch'],'origin':str(source),'artifact_sha256':{p.name:sha(p) for p in source.iterdir() if p.is_file()}})
 for origin in origins:
  check_origin(origin);shutil.copytree(origin['origin'],assembled/origin['batch'])
 shutil.copyfile(latest/'manifest.json',assembled/'manifest.json')
 rows=[]
 for assignment in manifest['assignments']:
  b=[lookup[x] for x in assignment['packet_ids']]
  fp=judge.digest({'packets':b,'instruction':judge.INSTRUCTION,'schema':judge.SCHEMA,'model':'gpt-6-astra','effort':'low','pass':assignment['pass']})
  r=read(assembled/f"pass-{assignment['pass']}-{fp[:16]}"/'result.json')
  rows.extend({'pass':assignment['pass'],**row} for row in r['judgments'])
 (assembled/'judgments.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
 # Existing strict verifier checks every raw stream, final, schema and prompt.
 sys.path.insert(0,str(ROOT/'harness'));import assess
 verified=assess.verified_judgments(assembled,manifest['packets'],assess.judge_config())
 require(len(verified)==360,'Incomplete assembled judgments')
 write_new(assembled/'recovery-provenance.json',{'amendment':'Post-launch transport-only recovery, not an untouched preregistered campaign.',
  'decision_sha256':sha(decision_path),'limits_sha256':sha(ROOT/'SINGLE-RECOVERY-LIMITS.json'),'approval_sha256':sha(ROOT/'SINGLE-RECOVERY-APPROVAL.json'),
  'accepted_origins':origins,'assembled_artifact_sha256':{str(p.relative_to(assembled)):sha(p) for p in assembled.rglob('*') if p.is_file()},
  'initial_campaign_votes_used':False,'latest_valid_batches_preserved':71,'recovery_attempts':1,'verified_judgments':len(verified)})
 print(json.dumps({'valid':True,'verified_judgments':len(verified),'assembled':str(assembled)}));return 0

if __name__=='__main__':raise SystemExit(main())
