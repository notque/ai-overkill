from pathlib import Path
p=Path(__file__).with_name('report.py');s=p.read_text().replace("ROOT/'judges'","ROOT/'judges-rerun'")
s=s.replace("('live_judges',ROOT/'judges-rerun')", "('initial_live_judges',ROOT/'judges'),('fresh_live_judges',ROOT/'judges-rerun')")
pos=s.index('def report():')
helper='''def resolved_outcomes(metrics):
 packets=judge.prepare_packets(ROOT/'packets.jsonl',CORPUS)
 votes=assess.verified_judgments(ROOT/'judges-rerun',packets,assess.judge_config())
 by_id={p['id']:[] for p in packets}
 for row in votes:by_id[row['id']].append(row)
 disputed={}
 for identifier,pair in by_id.items():
  checks=[{c['id']:c['score'] for c in r['checks']} for r in pair]
  critical=[{c['criterion']:c['violated'] for c in r['critical_violations']} for r in pair]
  cd={k for k in checks[0] if checks[0][k]!=checks[1][k]};vd={k for k in critical[0] if critical[0][k]!=critical[1][k]}
  if cd or vd:disputed[identifier]=(cd,vd)
 resolutions={};locked_hash=None;unresolved=[]
 if disputed:
  file=ROOT/'adjudications.jsonl';locked_hash=(ROOT/'adjudications.jsonl.sha256').read_text().split()[0]
  require(hashlib.sha256(file.read_bytes()).hexdigest()==locked_hash,'Adjudication lock mismatch')
  entries=rows(file);require(len(entries)==len(disputed) and {r['id'] for r in entries}==set(disputed),'Adjudication coverage mismatch')
  for entry in entries:
   identifier=entry['id'];cd,vd=disputed[identifier]
   if entry.get('unresolved') is True:
    unresolved.append(identifier);continue
   require(entry.get('unresolved') is False,'Missing resolution status')
   checks=entry.get('checks',[]);critical=entry.get('critical_violations',[])
   require(len(checks)==len(cd) and {c['id'] for c in checks}==cd,'Adjudication changed undisputed check')
   require(len(critical)==len(vd) and {c['criterion'] for c in critical}==vd,'Adjudication changed undisputed critical vote')
   for check in checks:
    require(type(check.get('score')) is int and check['score'] in (0,1) and check.get('evidence') and check.get('rationale'),'Incomplete semantic adjudication')
   for violation in critical:
    require(type(violation.get('violated')) is bool and violation.get('evidence') and violation.get('rationale'),'Incomplete critical adjudication')
   resolutions[identifier]=entry
 # Arms are read only after independent adjudications have been locked and validated.
 mapping=read(ROOT/'map.json')['packets'];case_scores={};case_critical={}
 for identifier,pair in by_id.items():
  assignment=mapping[identifier]['assignment'];key=(assignment['case_id'],assignment['arm'])
  checks={c['id']:c['score'] for c in pair[0]['checks']};critical={c['criterion']:c['violated'] for c in pair[0]['critical_violations']}
  if identifier in resolutions:
   checks.update({c['id']:c['score'] for c in resolutions[identifier]['checks']})
   critical.update({c['criterion']:c['violated'] for c in resolutions[identifier]['critical_violations']})
  case_scores.setdefault(key,[]).append(sum(checks.values())/len(checks));case_critical[key]=case_critical.get(key,0)+sum(critical.values())
 cases=sorted({case for case,arm in case_scores});utility={case:{arm:sum(case_scores[(case,arm)])/len(case_scores[(case,arm)]) for arm in ('baseline','challenger')} for case in cases}
 critical={case:{arm:case_critical[(case,arm)] for arm in ('baseline','challenger')} for case in cases}
 regressions=[case for case in cases if utility[case]['challenger']<utility[case]['baseline'] or critical[case]['challenger']>critical[case]['baseline']]
 return {'initial_disputed_packets':len(disputed),'adjudication_sha256':locked_hash,'resolved_packets':len(resolutions),'unresolved':unresolved,'case_utility':utility,'critical_violations':critical,'regressions':regressions}

'''
s=s[:pos]+helper+s[pos:]
s=s.replace(" metrics=assess.assess(ROOT/'results',ROOT/'judges-rerun',ROOT/'map.json')", " adjudication=resolved_outcomes(None)\n metrics=assess.assess(ROOT/'results',ROOT/'judges-rerun',ROOT/'map.json')")
s=s.replace("not metrics['regressions'] and not metrics['disagreements']", "not adjudication['regressions'] and not adjudication['unresolved']")
s=s.replace("if metrics['disagreements'] else 'PASS_DOCUMENT_REVIEW'", "if adjudication['unresolved'] else 'PASS_DOCUMENT_REVIEW'")
s=s.replace("'quality_pass':quality,", "'adjudication':adjudication,'quality_pass':quality,")
p.write_text(s)
a=Path(__file__).with_name('prepare_adjudication.py');a.write_text(a.read_text().replace("root/'judges'","root/'judges-rerun'"))
