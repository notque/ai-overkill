import json,sys
from collections import defaultdict
from pathlib import Path
root=Path(__file__).parent;sys.path.insert(0,str(root/'harness'))
import assess,judge
packets=judge.prepare_packets(root/'packets.jsonl',Path('/nonexistent/no-live-rubrics'))
rows=assess.verified_judgments(root/'judges-assembled',packets,assess.judge_config())
by_id=defaultdict(list)
for row in rows:by_id[row['id']].append(row)
disputes=[]
for packet in packets:
 votes=by_id[packet['id']]
 signatures=[(sorted((c['id'],c['score']) for c in v['checks']),sorted((c['criterion'],c['violated']) for c in v['critical_violations'])) for v in votes]
 if signatures[0]!=signatures[1]:disputes.append({**packet,'votes':votes})
(root/'adjudication.blind.jsonl').write_text(''.join(json.dumps(p)+'\n' for p in disputes))
print(json.dumps({'validated_judgments':len(rows),'disputed_packets':len(disputes)}))
