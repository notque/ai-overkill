"""Frozen base-rules experiment policy interpreter; never changes measured inputs."""
import hashlib,json,sys
from pathlib import Path
from statistics import median
from fractions import Fraction
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'harness'))
import assess,judge,runner
CORPUS=Path('/tmp/vexjoy-base-rules-corpus')

def read(path):return json.loads(path.read_text())
def rows(path):return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
def require(value,message):
 if not value:raise ValueError(message)

def calibration():
 protocol=read(ROOT/'protocol.json')
 for name,expected_hash in protocol['corpus_sha256s'].items():
  require(hashlib.sha256((CORPUS/name).read_bytes()).hexdigest()==expected_hash,'Frozen corpus drift: '+name)
 for name,expected_hash in protocol['harness_sha256s'].items():
  require(hashlib.sha256((ROOT/'harness'/name).read_bytes()).hexdigest()==expected_hash,'Frozen harness drift: '+name)
 source_record=read(ROOT/'judge-rerun-source.json')
 for name,expected_hash in source_record['source_sha256'].items():
  require(hashlib.sha256((ROOT/'harness-rerun'/name).read_bytes()).hexdigest()==expected_hash,'Fresh judge source drift: '+name)
 directory=ROOT/'calibration-blind-judges'
 packets=judge.prepare_packets(ROOT/'calibration.blind.jsonl',CORPUS)
 config={**assess.judge_config(),'calibration':True}
 assignments=assess.judge_batches(packets,config)
 expected_manifest={**config,'packets':packets,'assignments':[{'pass':p,'packet_ids':[x['id'] for x in b]} for p,b in assignments]}
 require(read(directory/'manifest.json')==expected_manifest,'Calibration manifest mismatch')
 private=read(ROOT/'calibration.private-map.json')
 expected={r['output_id']:r['expected_checks'] for r in rows(CORPUS/'calibration.expected.jsonl')}
 results=[];mismatches=[]
 for number,batch in assignments:
  fingerprint=judge.digest({'packets':batch,'instruction':judge.INSTRUCTION,'schema':judge.SCHEMA,'model':'gpt-6-astra','effort':'low','pass':number})
  target=directory/f'pass-{number}-{fingerprint[:16]}'
  result=read(target/'result.json')
  require(result.get('valid') is True and result.get('returncode')==0 and result.get('calibration') is True and not result.get('error'),'Invalid calibration batch')
  require(result.get('fingerprint')==fingerprint and result.get('pass')==number and result.get('packet_ids')==[p['id'] for p in batch],'Calibration batch identity mismatch')
  require(result.get('usage')==judge.parse_events((target/'events.jsonl').read_text()),'Calibration usage mismatch')
  final=read(target/'final.json');scores=judge.validate(final,batch)
  messages=[e['item']['text'] for e in rows(target/'events.jsonl') if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='agent_message']
  require(messages and json.loads(messages[-1])==final and result['judgments']==scores,'Calibration raw final mismatch')
  prefix=judge.INSTRUCTION+'\nPACKETS:\n';prompt=(target/'prompt.txt').read_text()
  require(prompt.startswith(prefix) and json.loads(prompt[len(prefix):])==batch and read(target/'schema.json')==judge.SCHEMA,'Calibration prompt/schema mismatch')
  for score in scores:
   checks=expected[private[score['id']]]
   require(set(checks)=={c['id'] for c in score['checks']},'Calibration expected criterion mismatch')
   actual={c['id']:c['score'] for c in score['checks']}
   critical_expected=not all(value==1 for value in checks.values())
   if actual!=checks or any(c['violated']!=critical_expected for c in score['critical_violations']):
    mismatches.append({'packet':score['id'],'pass':number,'semantic_expected':checks,'semantic_actual':actual,'critical_expected':critical_expected,'critical_actual':score['critical_violations']})
   results.append({'pass':number,**score})
 require(rows(directory/'judgments.jsonl')==results,'Calibration export mismatch')
 return {'passed':not mismatches,'judgments':len(results),'mismatches':mismatches,'rejected_first_calibration':'Semantic source labels in packet IDs; cost retained.'}

def cost():
 totals={key:0 for key in ('input_tokens','cached_input_tokens','output_tokens')};unknown=[];groups={}
 for label,path in [('generation',ROOT/'results'/'raw'),('ineligible_calibration',ROOT/'calibration-judges'),('blind_calibration',ROOT/'calibration-blind-judges'),('initial_live_judges',ROOT/'judges'),('fresh_live_judges',ROOT/'judges-rerun'),('single_transport_recovery',ROOT/'judge-single-recovery')]:
  group={key:0 for key in totals};count=0
  for result_path in sorted(path.rglob('result.json')):
   count+=1;result=read(result_path)
   try:
    usage=judge.validate_usage(result.get('usage'))
   except ValueError:
    unknown.append(str(result_path));continue
   for key in totals:totals[key]+=usage[key];group[key]+=usage[key]
  groups[label]={'completed_artifacts':count,**group}
 return {'groups':groups,**totals,'total_input_plus_output':totals['input_tokens']+totals['output_tokens'],'unknown_usage_artifacts':unknown,'scope':'Measured model generation and judge calls; coordinating-agent overhead unavailable and not asserted zero.'}

def resolved_outcomes(metrics):
 packets=judge.prepare_packets(ROOT/'packets.jsonl',CORPUS)
 votes=assess.verified_judgments(ROOT/'judges-assembled',packets,assess.judge_config())
 by_id={p['id']:[] for p in packets}
 for row in votes:by_id[row['id']].append(row)
 disputed={}
 for identifier,pair in by_id.items():
  checks=[{c['id']:c['score'] for c in r['checks']} for r in pair]
  critical=[{c['criterion']:c['violated'] for c in r['critical_violations']} for r in pair]
  cd={k for k in checks[0] if checks[0][k]!=checks[1][k]};vd={k for k in critical[0] if critical[0][k]!=critical[1][k]}
  if cd or vd:disputed[identifier]=(cd,vd)
 resolutions={};locked_hash=None;unresolved=[]
 if disputed:
  file=ROOT/'adjudications.jsonl';locked_hash=(ROOT/'adjudications.jsonl.sha256').read_text().split()[0]
  require(hashlib.sha256(file.read_bytes()).hexdigest()==locked_hash,'Adjudication lock mismatch')
  entries=rows(file);require(len(entries)==len(disputed) and {r['id'] for r in entries}==set(disputed),'Adjudication coverage mismatch')
  for entry in entries:
   identifier=entry['id'];cd,vd=disputed[identifier]
   if entry.get('unresolved') is True:
    unresolved.append(identifier);continue
   require(entry.get('unresolved') is False,'Missing resolution status')
   checks=entry.get('checks',[]);critical=entry.get('critical_violations',[])
   require(len(checks)==len(cd) and {c['id'] for c in checks}==cd,'Adjudication changed undisputed check')
   require(len(critical)==len(vd) and {c['criterion'] for c in critical}==vd,'Adjudication changed undisputed critical vote')
   for check in checks:
    require(type(check.get('score')) is int and check['score'] in (0,1) and check.get('evidence') and check.get('rationale'),'Incomplete semantic adjudication')
   for violation in critical:
    require(type(violation.get('violated')) is bool and violation.get('evidence') and violation.get('rationale'),'Incomplete critical adjudication')
   resolutions[identifier]=entry
 # Arms are read only after independent adjudications have been locked and validated.
 mapping=read(ROOT/'map.json')['packets'];case_scores={};case_critical={}
 for identifier,pair in by_id.items():
  assignment=mapping[identifier]['assignment'];key=(assignment['case_id'],assignment['arm'])
  checks={c['id']:c['score'] for c in pair[0]['checks']};critical={c['criterion']:c['violated'] for c in pair[0]['critical_violations']}
  if identifier in resolutions:
   checks.update({c['id']:c['score'] for c in resolutions[identifier]['checks']})
   critical.update({c['criterion']:c['violated'] for c in resolutions[identifier]['critical_violations']})
  case_scores.setdefault(key,[]).append(Fraction(sum(checks.values()),len(checks)));case_critical[key]=case_critical.get(key,0)+sum(critical.values())
 cases=sorted({case for case,arm in case_scores});utility={case:{arm:float(sum(case_scores[(case,arm)])/len(case_scores[(case,arm)])) for arm in ('baseline','challenger')} for case in cases}
 critical={case:{arm:case_critical[(case,arm)] for arm in ('baseline','challenger')} for case in cases}
 regressions=[case for case in cases if utility[case]['challenger']<utility[case]['baseline'] or critical[case]['challenger']>critical[case]['baseline']]
 return {'initial_disputed_packets':len(disputed),'adjudication_sha256':locked_hash,'resolved_packets':len(resolutions),'unresolved':unresolved,'case_utility':utility,'critical_violations':critical,'regressions':regressions}

def verify_recovery():
 directory=ROOT/'judges-assembled';receipt=read(directory/'recovery-provenance.json')
 for key,name in [('decision_sha256','SINGLE-RECOVERY-DECISION.json'),('limits_sha256','SINGLE-RECOVERY-LIMITS.json'),('approval_sha256','SINGLE-RECOVERY-APPROVAL.json')]:
  require(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==receipt[key],'Recovery approval/provenance changed')
 for relative,expected in receipt['assembled_artifact_sha256'].items():
  require(hashlib.sha256((directory/relative).read_bytes()).hexdigest()==expected,'Assembled artifact changed')
 for origin in receipt['accepted_origins']:
  for name,expected in origin['artifact_sha256'].items():
   require(hashlib.sha256((Path(origin['origin'])/name).read_bytes()).hexdigest()==expected,'Accepted origin changed')
 require(receipt['latest_valid_batches_preserved']==71 and receipt['recovery_attempts']==1 and receipt['initial_campaign_votes_used'] is False,'Recovery selection policy mismatch')
 return {'amendment':receipt['amendment'],'receipt_sha256':hashlib.sha256((directory/'recovery-provenance.json').read_bytes()).hexdigest(),'accepted_latest_batches':71,'single_recovery_attempts':1,'prior_votes_excluded':True}

def report():
 recovery=verify_recovery()
 cal=calibration();require(cal['passed'],'Calibration did not pass exact preregistered labels')
 adjudication=resolved_outcomes(None)
 metrics=assess.assess(ROOT/'results',ROOT/'judges-assembled',ROOT/'map.json')
 _,protocol,_,records=assess.records(ROOT/'results','all')
 require(len(records)==180,'Expected all180 samples')
 malformed=[a['uid'] for a,r,_ in records if not isinstance(r.get('answer'),dict) or set(r['answer'])!={'answer'} or not isinstance(r['answer'].get('answer'),str) or len(r['answer']['answer'].split())>180]
 by_repeat={number:[] for number in range(5)}
 for assignment,result,_ in records:
  if assignment['arm']=='baseline':by_repeat[assignment['repeat']].append(result['usage']['input_tokens']+result['usage']['output_tokens'])
 require(all(len(v)==18 for v in by_repeat.values()),'Incomplete baseline noise denominator')
 baseline_medians=[median(by_repeat[r]) for r in range(5)];noise=max(baseline_medians)-min(baseline_medians)
 total=metrics['metrics']['total_tokens'];saving=total['baseline_median']-total['challenger_median']
 quality=not metrics['failures'] and not adjudication['regressions'] and not adjudication['unresolved'] and not malformed
 efficiency=total['reduction']>=.01 and saving>2*noise
 verdict='INCONCLUSIVE' if adjudication['unresolved'] else 'PASS_DOCUMENT_REVIEW' if quality and efficiency else 'REJECT'
 return {'verdict':verdict,'scope':protocol['scope'],'policy_source':str(ROOT/'protocol.json'),
  'generic_assessor_status_ignored':metrics['status'],'generic_policy_not_applicable':'This frozen trial uses18cases/180runs and1% plus measured-noise threshold; generic5%/300 gate intentionally not controlling. Raw vote disagreements, if any, require separately hash-locked independent adjudication, never averaging.',
  'judge_campaign':'judges-assembled (latest71valid + one approved timeout recovery)','initial_judge_campaign':'judges (infrastructure-failed; archived, no vote reuse)','transport_recovery':recovery,'adjudication':adjudication,'quality_pass':quality,'efficiency_pass':efficiency,'worker_contract_audit':{k:v for k,v in read(ROOT/'worker-contract-audit.json').items() if k!='records'},'contract_violations':malformed,
  'baseline_repeat_corpus_medians':baseline_medians,'baseline_noise_range':noise,'required_absolute_saving_strictly_greater_than':2*noise,
  'observed_global_median_saving':saving,'calibration':cal,'metrics':metrics,'experiment_cost':cost(),
  'limitations':['Tests output interpretation/writing only; no autonomous execution or compliance inference.','Fixed case corpus, same-model independent judge passes; narrow source edit.','Requires parent review and all project CI; no automatic publication.']}

if __name__=='__main__':
 try:
  result=calibration() if '--calibration-only' in sys.argv else report()
 except (ValueError,KeyError,TypeError,OSError) as error:
  result={'verdict':'INVALID','error':str(error),'experiment_cost':cost()}
 path=ROOT/('calibration-report.json' if '--calibration-only' in sys.argv else 'RECOVERY-REPORT.json')
 path.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result if '--calibration-only' in sys.argv else {k:v for k,v in result.items() if k not in ('metrics','calibration')},indent=2))
